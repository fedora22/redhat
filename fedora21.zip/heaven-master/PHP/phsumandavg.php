<?php
if( $_GET["no1"] || $_GET["no2"] )
   {
$sum=$_GET['no1']+$_GET['no2'];
      echo "Sum ".$sum . "<br />";
exit();
 }
?>
<html>
   <body>
   
      <form action="<?php $_PHP_SELF ?>" method="GET">
        Number1 <input type="text" name="no1" />
	Number2 <input type="text" name="no2" />
	 <input type="submit" />
      </form>
      
   </body>
</html>

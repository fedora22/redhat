<?php
   $dbhost = "localhost";
   $dbuser = "root";
   $dbpass = "1234567890";
   $conn = mysql_connect($dbhost, $dbuser, $dbpass);
   
   if(! $conn )
   {
      die('Could not connect: ' . mysql_error());
   }
	echo "connection established";  
   mysql_select_db('perldb');
$sql1 = 'INSERT INTO perltable VALUES(5,"hello")';
   $retval1 = mysql_query( $sql1, $conn);

$sql = 'SELECT * FROM perltable';

   $retval = mysql_query( $sql, $conn );
echo "query executed </br>";


   while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
   {
      echo "Roll no ". $row['roll_no']."</br>";
	echo "Name ". $row['name']."</br>";
   }
   
   echo "Fetched data successfully";
   
 mysql_close($conn);
?>

<?php

if($_GET['n'] && $_GET['nos'])
{
$numstring=$_GET['nos'];
$numarray=explode(' ',$numstring);

$sum=array_sum($numarray);
echo "sum is ".$sum."</br>";

$average=$sum/$_GET['n'];
echo "average is ".$average;
exit();
}
?>

<html>
<body>

<form action="<?php $_PHP_SELF ?>"method= "GET">
N : <input type="text" name="n" />
Numbers : <input type="text" name="nos" />
<input type="submit" />
</form>

</body>
</html>

# Open file to read
open(DATA1, "<file1.txt");

# Open new file to write
open(DATA2, ">>file2.txt");#use > for copy  >> for concat

# Copy data from one file to another.
while(<DATA1>)
{
   printf DATA2;
}
close( DATA1 );
close( DATA2 );

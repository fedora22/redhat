printf "Enter the word you want to search for and press return:";

$sword=<STDIN>;

chomp($sword);

$scount = 0; #search counter

$bcount = 0; #blank line counter

while(<>) #continue reading as long as there is input

{

chomp; #remove newline from each line

foreach $w (split) #split each line into words

{

if ($w eq $sword)

{
$scount++; #search hit counter
}

$words++;

$char += length($w);

}

#if the length of the current line is 0, we have a blank line

if (length($_) == 0)

{

$bcount++;

}



}

$avgw = $words/$.; #average words per line including blank lines

$avgc = $char/$words; #average characters per word

print "There are $. lines in this file including $bcount blank

lines.\n";

print "There are $words words in this file.\n";

print "There are $char characters in this file.\n";

print "The average number of words per line is $avgw.\n";

print "The average number of characters per word is $avgc.\n";

print "the word $sword occurs in the text $scount times.\n";

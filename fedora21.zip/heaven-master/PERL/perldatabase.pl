 use DBI;
 $conn= DBI->connect("dbi:mysql:perldb","root","1234567890");
print "connection established\n"; 
#or die "Connection Error: $DBI::errstr\n";
 $rollno = '3';
 $name = "xyz";
 $query = "insert into perltable values(?,?);";
 $prepquery = $conn->prepare($query);
 $prepquery->execute($rollno,$name);
print "inserted\n";
# or die "SQL Error: $DBI::errstr\n";
 $query = "select * from perltable";
 $prepquery = $conn->prepare($query);
 $prepquery->execute;
print "selected\n";
# or die "SQL Error: $DBI::errstr\n";
 while (@row = $prepquery->fetchrow_array) {
 print "@row\n";
 } 

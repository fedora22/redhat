print "enter string1";
$string1=<>;
chomp($string1);
print "enter string2";
$string2=<>;
$string3= $string1.$string2;
print "$string3";


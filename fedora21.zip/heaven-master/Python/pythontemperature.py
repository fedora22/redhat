choice=input("Enter 1 for Celsius to Farenheit 2 for Farenheit to Celsius")
if choice==1:
	cel=float(input("Enter Celsius"))
	far=1.8*cel+32
	print(far)
elif choice==2:
	far=float(input("Enter Farenheit"))
	cel=(far-32)/1.8
	print(cel)
else:
	print("Invalid choice");


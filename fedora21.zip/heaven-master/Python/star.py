import turtle
turtle.setup(1000,1000)
window=turtle.Screen()
window.bgcolor("lightblue")
window.title("turtle")
tess=turtle.Turtle()
tess.shape("turtle")
tess.color("green")
tess.pensize(3)
tess.left(60)
tess.forward(200)#length is 200 to move in forward direction
tess.right(120)
tess.forward(200)#length is 200 to move in forward direction
tess.right(150)
tess.forward(250)#length is 200 to move in forward direction
tess.right(150)
tess.forward(250)#length is 200 to move in forward direction
tess.right(152)
tess.forward(250)#length is 200 to move in forward direction

window.exitonclick()
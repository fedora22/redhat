fin = open("file1.txt","r");
fout = open("file2.txt","r+");
for line in fout:
	fout.write(line)
for line in fin:
	fout.write(line)
fout.close()

import turtle
turtle.setup(1000,1000)
window=turtle.Screen()
window.bgcolor("lightblue")
window.title("turtle")
tess=turtle.Turtle()
tess.shape("turtle")
tess.color("green")
tess.pensize(3)
tess.forward(200)#length is 200 to move in forward direction
tess.left(120)#270 is the angle to turn left
tess.forward(200)
tess.left(120)
tess.forward(200)
window.exitonclick()

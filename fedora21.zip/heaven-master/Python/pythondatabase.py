import MySQLdb

# Open database connection
db = MySQLdb.connect("localhost","root","1234567890","perldb" )

# prepare a cursor object using cursor() method
cursor = db.cursor()
cursor.execute("insert into perltable values(1,'xxx');")
cursor.execute("SELECT * from perltable;")
data = cursor.fetchall()

for row in data :
	print row[0], row[1]


cursor.execute("delete from perltable;")
cursor.execute("insert into perltable values(2,'yyy');")
cursor.execute("insert into perltable values(3,'zzz');")
# execute SQL query using execute() method.
cursor.execute("SELECT * from perltable;")

data = cursor.fetchall()

for row in data :
	print row[0], row[1]

db.commit()
# Fetch a single row using fetchone() method.
# disconnect from server
db.close()

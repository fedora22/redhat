import turtle
turtle.setup(1000,1000)
window=turtle.Screen()
window.bgcolor("white")
window.title("turtle")
tess=turtle.Turtle()
tess.shape("turtle")
tess.color("green")
#tess.penup()
size=10
for i in range(30):
	tess.stamp()
	size = size + 3
	tess.forward(size)
	tess.right(24)
window.exitonclick()

import turtle
turtle.setup(1000,1000)
window=turtle.Screen()
window.bgcolor("lightblue")
window.title("turtle")
tess=turtle.Turtle()
tess.shape("turtle")
tess.color("green")
tess.penup()
size=10
for i in range(30):
	tess.stamp()
	size = size + 3
	tess.backward(size)
	tess.right(24)
window.exitonclick()

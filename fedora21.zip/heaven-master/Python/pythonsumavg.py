n=input("enter number of elements");
s=0
for i in range(n):
	s=s+input("enter numbers");
print("sum is")
print(s)
print("avg is")
print(s/n)

